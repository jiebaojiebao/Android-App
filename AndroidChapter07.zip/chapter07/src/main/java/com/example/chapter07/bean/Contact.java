package com.example.chapter07.bean;

public class Contact {
    public String contactId; // 联系人编号
    public String name; // 联系人姓名
    public String phone; // 联系号码
    public String email; // 邮箱

    public Contact() {
        contactId = "";
        name = "";
        phone = "";
        email = "";
    }
}
