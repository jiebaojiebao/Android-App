package com.example.chapter05;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class EditBorderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_border);
    }

}
