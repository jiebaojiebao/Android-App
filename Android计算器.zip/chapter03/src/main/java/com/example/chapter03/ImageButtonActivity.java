package com.example.chapter03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ImageButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_button);
    }
}
