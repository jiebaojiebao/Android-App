package com.example.network.bean;

public class JoinInfo {
    public String user_name; // 用户名称
    public String group_name; // 群组名称

    public JoinInfo(String user_name, String group_name) {
        this.user_name = user_name;
        this.group_name = group_name;
    }

}
