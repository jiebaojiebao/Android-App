package com.example.network.bean;

public class EntityInfo {
    public String name; // 实体名称
    public String relation; // 实体关系

    public EntityInfo(String name, String relation) {
        this.name = name;
        this.relation = relation;
    }
}
