package com.example.video.constant;

public class UrlConstant {
    public final static String HTTP_PREFIX = "http://192.168.1.7:8080/HttpServer/";
    //http://localhost:8080/HttpServer/commitVideo
    //http://localhost:8080/HttpServer/queryVideo
}
