package com.example.location.bean;

public class JoinResponse {
    private String code; // 结果代码
    private String desc; // 结果描述

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return this.desc;
    }
}
