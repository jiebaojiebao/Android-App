package com.example.chapter10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CustomButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_button);
    }
}
